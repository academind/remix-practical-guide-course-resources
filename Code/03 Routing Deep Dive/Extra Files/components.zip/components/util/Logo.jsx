function Logo() {
  return (
    <h1 id="logo">
      <a href="/">RemixExpenses</a>
    </h1>
  );
}

export default Logo;
